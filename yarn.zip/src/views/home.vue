<script setup lang="ts">
import BarNav from '@/views/components/barNav.vue'
const title = "首页";
function btn(){

}
// console.log(6666,store,store.state.loginToken)
</script>

<template>
  <div id="home">
    <BarNav :title="title"></BarNav>
  </div>
</template>

<style scoped lang="less" >
#home{
 
}
</style>
