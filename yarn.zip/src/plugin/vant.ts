
import { createApp } from 'vue'
import {
    Button,
} from 'vant'
// const plugins = {
//     Button 
// }
createApp().use(Button);

export default{
    // plugins
    Button
}